/* HAL-only entry function */
#include "hal_data.h"
void hal_entry(void)
{
}
